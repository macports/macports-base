/*
 * Copyright (c) 2012, Novell Inc.
 *
 * This program is licensed under the BSD license, read LICENSE.BSD
 * for further information
 */

extern int repo_add_cudf(Repo *repo, Repo *installedrepo, FILE *fp, Queue *job, int flags);

