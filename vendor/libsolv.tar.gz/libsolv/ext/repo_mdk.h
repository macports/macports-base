/*
 * Copyright (c) 2012, Novell Inc.
 *
 * This program is licensed under the BSD license, read LICENSE.BSD
 * for further information
 */

extern int repo_add_mdk(Repo *repo, FILE *fp, int flags);
extern int repo_add_mdk_info(Repo *repo, FILE *fp, int flags);

